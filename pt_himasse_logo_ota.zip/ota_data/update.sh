#!/sbin/sh

# リカバリーの出力先FD (基本は2)
OUTFD=2
ui_print() {
    echo -n -e "ui_print $1\n" > /proc/self/fd/$OUTFD
    echo -n -e "ui_print\n" > /proc/self/fd/$OUTFD
}

ui_print "Mounting partitions..."
# キャッシュとシステムの書き換え準備
mount /dev/block/by-name/cache /cache 2>/dev/null
mount -o rw,remount /system_root 2>/dev/null
mount -o rw,remount /system 2>/dev/null

# ターゲットディレクトリの確定 (sys-as-root対応)
if [ -d "/system_root/system" ]; then
    T_DIR="/system_root/system"
else
    T_DIR="/system"
fi

ui_print "Target: $T_DIR"

# ロゴ焼き (dd)
ui_print "Writing logo..."
dd if=/tmp/ota_data/benesse_logo.bin of=/dev/block/mmcblk0p17

# ファイル同期 (cp)
if [ -d "/tmp/ota_data/system" ]; then
    ui_print "Syncing system files..."
    cp -rf /tmp/ota_data/system/* "$T_DIR/"
fi

# 権限設定 (必要に応じて追加)
toybox chmod 644 "$T_DIR/app/YourApp.apk"

# 後片付け
ui_print "Cleaning up..."
rm -rf /tmp/ota_data

ui_print "Done. Rebooting..."
reboot